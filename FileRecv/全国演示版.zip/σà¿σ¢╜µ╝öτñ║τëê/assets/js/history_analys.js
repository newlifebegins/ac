/**
 * Created by stormmys on 2017/4/15.
 */
var chart_scene_tj_pie = echarts.init(document.getElementById('scene_tj_pie'));
function scene_tj_pie() {

    option = {
        tooltip : {
            trigger: 'axis',
            axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
        },
        legend: {
            data: ['严重污染', '重度污染','中度污染','轻度污染','良','优']
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis:  {
            type: 'value'
        },
        yAxis: {
            type: 'category',
            data: ['2013年','2014年','2015年','2016年']
        },
        series: [
            {
                name: '严重污染',
                type: 'bar',
                stack: '总量',
                label: {
                    normal: {
                        show: true,
                        position: 'insideRight'
                    }
                },
                data: [13, 15, 15, 9]
            },
            {
                name: '重度污染',
                type: 'bar',
                stack: '总量',
                label: {
                    normal: {
                        show: true,
                        position: 'insideRight'
                    }
                },
                data: [45,32, 31, 30]
            },
            {
                name: '中度污染',
                type: 'bar',
                stack: '总量',
                label: {
                    normal: {
                        show: true,
                        position: 'insideRight'
                    }
                },
                data: [47, 61, 62, 51]
            },
            {
                name: '轻度污染',
                type: 'bar',
                stack: '总量',
                label: {
                    normal: {
                        show: true,
                        position: 'insideRight'
                    }
                },
                data: [84, 85, 71, 78]
            },
            {
                name: '良',
                type: 'bar',
                stack: '总量',
                label: {
                    normal: {
                        show: true,
                        position: 'insideRight'
                    }
                },
                data: [135, 133, 134, 130]
            },
            {
                name: '优',
                type: 'bar',
                stack: '总量',
                label: {
                    normal: {
                        show: true,
                        position: 'insideRight'
                    }
                },
                data: [41, 39, 52, 68]
            }
        ]
    };
    chart_scene_tj_pie.setOption(option);
}

var chart_hotel_tj_pie = echarts.init(document.getElementById('hotel_tj_pie'));
function hotel_tj_pie() {
    option = {
        title : {
            //text: '近年北京主要污染物浓度情况',
           // subtext: '数据来源：罗克佳华'
        },
        tooltip : {
            trigger: 'axis'
        },
        legend: {
            data:['PM2.5','PM10','NO2','SO2']
        },
        toolbox: {
            show : true,
            feature : {
                dataView : {show: true, readOnly: false},
                magicType : {show: true, type: ['line', 'bar']},
                restore : {show: true},
                saveAsImage : {show: true}
            }
        },
        calculable : true,
        xAxis : [
            {
                type : 'category',
                data : ['2013年','2014年','2015年','2016年']
            }
        ],
        yAxis : [
            {
                type : 'value'
            }
        ],
        series : [
            {
                name:'PM2.5',
                type:'bar',
                data:[89.5, 85.9, 80.6, 73],
                markPoint : {
                    data : [
                        {type : 'max', name: '最大值'},
                        {type : 'min', name: '最小值'}
                    ]
                },
                markLine : {
                    data : [
                        {type : 'average', name: '平均值'}
                    ]
                }
            },
            {
                name:'PM10',
                type:'bar',
                data:[108, 115.8, 101.5, 92],
                markPoint : {
                    data : [
                        {type : 'max', name: '最大值'},
                        {type : 'min', name: '最小值'}
                    ]
                },
                markLine : {
                    data : [
                        {type : 'average', name : '平均值'}
                    ]
                }
            },
            {
                name:'NO2',
                type:'bar',
                data:[56, 56.7, 50, 48],
                markPoint : {
                    data : [
                        {type : 'max', name: '最大值'},
                        {type : 'min', name: '最小值'}
                    ]
                },
                markLine : {
                    data : [
                        {type : 'average', name : '平均值'}
                    ]
                }
            },
            {
                name:'SO2',
                type:'bar',
                data:[26.5, 21.8, 13.5, 10],
                markPoint : {
                    data : [
                        {type : 'max', name: '最大值'},
                        {type : 'min', name: '最小值'}
                    ]
                },
                markLine : {
                    data : [
                        {type : 'average', name : '平均值'}
                    ]
                }
            }
        ]
    };
    chart_hotel_tj_pie.setOption(option);
}
//travel_tj_pie
var chart_scene_tj_line = echarts.init(document.getElementById('scene_tj_line'));
function scene_tj_line() {
    option = {
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        legend: {
            orient: 'vertical',
            x: 'left',
            data:['PM2.5','O3','39个重污染天','其他时间']
        },
        series: [
            {
                name:'对全年污染贡献度',
                type:'pie',
                selectedMode: 'single',
                radius: [0, '40%'],

                label: {
                    normal: {
                        position: 'inner'
                    }
                },
                labelLine: {
                    normal: {
                        show: false
                    }
                },
                data:[
                    {value:31.5, name:'39个重污染天', selected:true},
                    {value:68.5, name:'其他时间'}
                ]
            },
            {
                name:'重污染天主要污染物',
                type:'pie',
                radius: ['52%', '71%'],

                data:[
                    {value:38, name:'PM2.5'},
                    {value:1, name:'O3'}
                ]
            }
        ]
    };
    chart_scene_tj_line.setOption(option);
}
var chart_hotel_tj_line = echarts.init(document.getElementById('hotel_tj_line'));
function hotel_tj_line() {
    option = {
        title : {
            // text: '2016年北京年均浓度达标情况',
            // subtext: '数据来源：罗克佳华'
        },
        tooltip : {
            trigger: 'axis'
        },
        legend: {
            data:['年均浓度','国家二级标准限值']
        },
        toolbox: {
            show : true,
            feature : {
                dataView : {show: true, readOnly: false},
                magicType : {show: true, type: ['line', 'bar']},
                restore : {show: true},
                saveAsImage : {show: true}
            }
        },
        calculable : true,
        xAxis : [
            {
                type : 'category',
                data : ['O3','PM10','PM2.5','NO2','SO2','CO']
            }
        ],
        yAxis : [
            {
                type : 'value',
                name: '浓度(单位:ug/m3;CO单位mg/m3)'
            }
        ],
        series : [
            {
                name:'蒸发量',
                type:'bar',
                data:[199, 92, 73, 48, 10, 3.2],

            },
            {
                name:'降水量',
                type:'bar',
                data:[160,70, 35,40, 60, 4.0],

            }
        ]
    };
    chart_hotel_tj_line.setOption(option);
}

//====
var chart_gongxian_pie = echarts.init(document.getElementById('gongxian_pie'));
function gongxian_pie() {
    option = {
        title : {
            text: '北京市六项污染物贡献率分布',
            subtext: '数据来自罗克佳华',
            x:'center'
        },
        tooltip : {
            trigger: 'item',
            formatter: "{a} <br/>{b} : {c} ({d}%)"
        },
        legend: {
            x : 'center',
            y : 'bottom',
            data:['PM2.5','PM10','NO2','SO2','CO','O3']
        },
        toolbox: {
            show : false,
            feature : {
                mark : {show: true},
                dataView : {show: true, readOnly: false},
                magicType : {
                    show: true,
                    type: ['pie', 'funnel']
                },
                restore : {show: true},
                saveAsImage : {show: true}
            }
        },
        calculable : true,
        series : [
            {
                name:'面积模式',
                type:'pie',
                radius : [30, 110],

                roseType : 'area',
                data:[
                    {value:1.692, name:'PM2.5'},
                    {value:1.965, name:'PM10'},
                    {value:0.903, name:'NO2'},
                    {value:0.122, name:'SO2'},
                    {value:0.303, name:'CO'},
                    {value:1.564, name:'O3'}
                ]
            }
        ]
    };
    chart_gongxian_pie.setOption(option);
}

var chart_wuran_duibi_column = echarts.init(document.getElementById('wuran_duibi_column'));
function wuran_duibi_column() {
    option = {
        title: {
            text: '城市污染对比',
            subtext: '数据来自罗克佳华'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data:['北京','上海','太原']
        },
        toolbox: {
            show: false,
            feature: {
                dataZoom: {
                    yAxisIndex: 'none'
                },
                dataView: {readOnly: false},
                magicType: {type: ['line', 'bar']},
                restore: {},
                saveAsImage: {}
            }
        },
        xAxis:  {
            type: 'category',
            boundaryGap: false,
            data: ['6月14日','6月15日','6月16日','6月17日','6月18日','6月19日','6月20日']
        },
        yAxis: {
            type: 'value',
            axisLabel: {
                formatter: '{value} °C'
            }
        },
        series: [
            {
                name:'北京',
                type:'line',
                data:[120, 156, 158, 199, 187, 151, 155],
                markPoint: {
                    data: [
                        {type: 'max', name: '最大值'},
                        {type: 'min', name: '最小值'}
                    ]
                },
                markLine: {
                    data: [
                        {type: 'average', name: '平均值'},
                        [{
                            symbol: 'none',
                            x: '90%',
                            yAxis: 'max'
                        }, {
                            symbol: 'circle',
                            label: {
                                normal: {
                                    position: 'start',
                                    formatter: '最大值'
                                }
                            },
                            type: 'max',
                            name: '最高点'
                        }]
                    ]
                }
            },
            {
                name:'上海',
                type:'line',
                data:[60, 82, 87, 106, 67, 45, 47],
                markPoint: {
                    data: [
                        {type: 'max', name: '最大值'},
                        {type: 'min', name: '最小值'}
                    ]
                },
                markLine: {
                    data: [
                        {type: 'average', name: '平均值'},
                        [{
                            symbol: 'none',
                            x: '90%',
                            yAxis: 'max'
                        }, {
                            symbol: 'circle',
                            label: {
                                normal: {
                                    position: 'start',
                                    formatter: '最大值'
                                }
                            },
                            type: 'max',
                            name: '最高点'
                        }]
                    ]
                }
            },
            {
                name:'太原',
                type:'line',
                data:[149, 147, 185, 153, 137, 90, 96],
                markPoint: {
                    data: [
                        {type: 'max', name: '最大值'},
                        {type: 'min', name: '最小值'}
                    ]
                },
                markLine: {
                    data: [
                        {type: 'average', name: '平均值'},
                        [{
                            symbol: 'none',
                            x: '90%',
                            yAxis: 'max'
                        }, {
                            symbol: 'circle',
                            label: {
                                normal: {
                                    position: 'start',
                                    formatter: '最大值'
                                }
                            },
                            type: 'max',
                            name: '最高点'
                        }]
                    ]
                }
            }
        ]
    };
    chart_wuran_duibi_column.setOption(option);
}

var chart_air_quality_pie = echarts.init(document.getElementById('air_quality_pie'));
function air_quality_pie() {
    option = {
        title : {
            text: '北京市5月份空气质量等级占比分布',
            subtext: '数据来自：罗克佳华',
            x:'center'
        },
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        legend: {
            x : 'center',
            y : 'bottom',
            data:['严重污染','重度污染','中度污染','轻度污染','良']
        },
        series: [
            {
                name:'污染天数',
                type:'pie',
                radius: ['50%', '70%'],
                avoidLabelOverlap: false,
                label: {
                    normal: {
                        show: false,
                        position: 'center'
                    },
                    emphasis: {
                        show: true,
                        textStyle: {
                            fontSize: '30',
                            fontWeight: 'bold'
                        }
                    }
                },
                labelLine: {
                    normal: {
                        show: false
                    }
                },
                data:[
                    {value:1, name:'严重污染'},
                    {value:1, name:'重度污染'},
                    {value:2, name:'中度污染'},
                    {value:13, name:'轻度污染'},
                    {value:14, name:'良'}
                ]
            }
        ]
    };
    chart_air_quality_pie.setOption(option);
}
var chart_gongxian_wangge = echarts.init(document.getElementById('gongxian_wangge'));
function gongxian_wangge() {
    option = {
        title: {
            text: '污染物贡献情况'
        },
        backgroundColor: 'rgba(255,255,255,0)',
        toolbox: {
            show: true,
            feature: {
                restore: {show: true},
                saveAsImage: {show: true}
            }
        },
        tooltip: {},
        legend: {
            data: ['北京污染物贡献', '太原污染物贡献']
        },
        radar: {
            // shape: 'circle',
            indicator: [
                {

                    name: 'PM2.5',

                    max: 2

                }, {

                    name: 'PM10',

                    max: 2

                }, {

                    name: 'NO2',

                    max: 2

                }, {

                    name: 'SO2',

                    max: 2

                }, {

                    name: 'CO',

                    max: 2

                }, {

                    name: 'O3',

                    max: 2

                }
                ,
            ]
        },
        series: [{
            name: '预算 vs 开销（Budget vs spending）',
            type: 'radar',
            // areaStyle: {normal: {}},
            itemStyle: {normal: {areaStyle: {type: 'default'}}},
            data : [
                {
                    value : [1.692, 1.965, 0.903, 0.122, 0.303, 1.564],
                    name : '北京污染物贡献'
                },
                {
                    value : [1.407, 1.921, 1.008, 0.324, 0.289, 1.297],
                    name : '太原污染物贡献'
                },
            ]
        }]
    };
    chart_gongxian_wangge.setOption(option);
}


$(window).resize(function () {
    chart_scene_tj_pie.resize();
    chart_hotel_tj_pie.resize();
    chart_scene_tj_line.resize();
    chart_hotel_tj_line.resize();
    chart_wuran_duibi_column.resize();
})
var SceneMain = function () {
    "use strict";
    return {
        init: function () {
            scene_tj_pie();
            hotel_tj_pie();
            scene_tj_line();
            hotel_tj_line();

            gongxian_pie();
            wuran_duibi_column();
            air_quality_pie();
            gongxian_wangge();
        }
    }
}()
