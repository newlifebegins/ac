function getCiColor(aqival){
    var _color=null;
    var _quality=null;
    var _iconUrl=null;
    if(aqival<=0 || isNaN(aqival)){
        _color='#6E6E6E';
        _quality="无";
        _iconUrl='assets/img/map/none.png';
    }
    else if(aqival<=50){
        _color='#43ce17';
        _quality="优";
        _iconUrl='assets/img/map/green.png';
    }
    else if(aqival<=100){
        _color='#efdc31';
        _quality="良";
        _iconUrl='assets/img/map/yellow.png';
    }
    else if(aqival<=150){
        _color='#fa0';
        _quality="轻度";
        _iconUrl='assets/img/map/orange.png';
    }
    else if(aqival<=200){
        _color='#ff401a';
        _quality="中度";
        _iconUrl='assets/img/map/red.png';
    }
    else if(aqival<=300){
        _color='#d20040';
        _quality="重度";
        _iconUrl='assets/img/map/violet.png';
    }
    else{
        _color='#9c0a4e';
        _quality="严重";
        _iconUrl='assets/img/map/black.png';
    }
    return {
        color:_color,
        quality:_quality,
        iconUrl:_iconUrl
    };
};
function getColor(aqival){
    var _color=null;
    var _quality=null;
    var _iconUrl=null;
    if(aqival<=0 || isNaN(aqival)){
        _color='#6E6E6E';
        _quality="无";
        _iconUrl='assets/img/map/none.png';
    }
    else if(aqival<=50){
        _color='#43ce17';
        _quality="优";
        _iconUrl='assets/img/map/green.png';
    }
    else if(aqival<=100){
        _color='#efdc31';
        _quality="良";
        _iconUrl='assets/img/map/yellow.png';
    }
    else if(aqival<=150){
        _color='#fa0';
        _quality="轻度";
        _iconUrl='assets/img/map/orange.png';
    }
    else if(aqival<=200){
        _color='#ff401a';
        _quality="中度";
        _iconUrl='assets/img/map/red.png';
    }
    else if(aqival<=300){
        _color='#d20040';
        _quality="重度";
        _iconUrl='assets/img/map/violet.png';
    }
    else{
        _color='#9c0a4e';
        _quality="严重";
        _iconUrl='assets/img/map/black.png';
    }
    return {
        color:_color,
        quality:_quality,
        iconUrl:_iconUrl
    };
};
function getPm25Color(aqival){
    var _color=null;
    var _quality=null;
    var _iconUrl=null;
    if(aqival<=0 || isNaN(aqival)){
        _color='#6E6E6E';
        _quality="无";
        _iconUrl='assets/img/map/none.png';
    }
    else if(aqival<=35){
        _color='#43ce17';
        _quality="优";
        _iconUrl='assets/img/map/green.png';
    }
    else if(aqival<=75){
        _color='#efdc31';
        _quality="良";
        _iconUrl='assets/img/map/yellow.png';
    }
    else if(aqival<=115){
        _color='#fa0';
        _quality="轻度";
        _iconUrl='assets/img/map/orange.png';
    }
    else if(aqival<=150){
        _color='#ff401a';
        _quality="中度";
        _iconUrl='assets/img/map/red.png';
    }
    else if(aqival<=250){
        _color='#d20040';
        _quality="重度";
        _iconUrl='assets/img/map/violet.png';
    }
    else{
        _color='#9c0a4e';
        _quality="严重";
        _iconUrl='assets/img/map/black.png';
    }
    return {
        color:_color,
        quality:_quality,
        iconUrl:_iconUrl
    };
};
function getPm10Color(aqival){
    var _color=null;
    var _quality=null;
    var _iconUrl=null;
    if(aqival<=0 || isNaN(aqival)){
        _color='#6E6E6E';
        _quality="无";
        _iconUrl='assets/img/map/none.png';
    }
    else if(aqival<=50){
        _color='#43ce17';
        _quality="优";
        _iconUrl='assets/img/map/green.png';
    }
    else if(aqival<=150){
        _color='#efdc31';
        _quality="良";
        _iconUrl='assets/img/map/yellow.png';
    }
    else if(aqival<=250){
        _color='#fa0';
        _quality="轻度";
        _iconUrl='assets/img/map/orange.png';
    }
    else if(aqival<=350){
        _color='#ff401a';
        _quality="中度";
        _iconUrl='assets/img/map/red.png';
    }
    else if(aqival<=420){
        _color='#d20040';
        _quality="重度";
        _iconUrl='assets/img/map/violet.png';
    }
    else{
        _color='#9c0a4e';
        _quality="严重";
        _iconUrl='assets/img/map/black.png';
    }
    return {
        color:_color,
        quality:_quality,
        iconUrl:_iconUrl
    };
};
function getCoColor(aqival){
    var _color=null;
    var _quality=null;
    var _iconUrl=null;
    if(aqival<=0 || isNaN(aqival)){
        _color='#6E6E6E';
        _quality="无";
        _iconUrl='assets/img/map/none.png';
    }
    else if(aqival<=5){
        _color='#43ce17';
        _quality="优";
        _iconUrl='assets/img/map/green.png';
    }
    else if(aqival<=10){
        _color='#efdc31';
        _quality="良";
        _iconUrl='assets/img/map/yellow.png';
    }
    else if(aqival<=35){
        _color='#fa0';
        _quality="轻度";
        _iconUrl='assets/img/map/orange.png';
    }
    else if(aqival<=60){
        _color='#ff401a';
        _quality="中度";
        _iconUrl='assets/img/map/red.png';
    }
    else if(aqival<=90){
        _color='#d20040';
        _quality="重度";
        _iconUrl='assets/img/map/violet.png';
    }
    else{
        _color='#9c0a4e';
        _quality="严重";
        _iconUrl='assets/img/map/black.png';
    }
    return {
        color:_color,
        quality:_quality,
        iconUrl:_iconUrl
    };
};
function getCo2Color(aqival){
    var _color=null;
    var _quality=null;
    var _iconUrl=null;
    if(aqival<=0 || isNaN(aqival)){
        _color='#6E6E6E';
        _quality="无";
        _iconUrl='assets/img/map/none.png';
    }
    else if(aqival<=700){
        _color='#43ce17';
        _quality="优";
        _iconUrl='assets/img/map/green.png';
    }
    else if(aqival<=100){
        _color='#efdc31';
        _quality="良";
        _iconUrl='assets/img/map/yellow.png';
    }
    else if(aqival<=1500){
        _color='#fa0';
        _quality="轻度";
        _iconUrl='assets/img/map/orange.png';
    }
    else if(aqival<=2000){
        _color='#ff401a';
        _quality="中度";
        _iconUrl='assets/img/map/red.png';
    }
    else if(aqival<=5000){
        _color='#d20040';
        _quality="重度";
        _iconUrl='assets/img/map/violet.png';
    }
    else{
        _color='#9c0a4e';
        _quality="严重";
        _iconUrl='assets/img/map/black.png';
    }
    return {
        color:_color,
        quality:_quality,
        iconUrl:_iconUrl
    };
};
function getO3Color(aqival){
    var _color=null;
    var _quality=null;
    var _iconUrl=null;
    if(aqival<=0 || isNaN(aqival)){
        _color='#6E6E6E';
        _quality="无";
        _iconUrl='assets/img/map/none.png';
    }
    else if(aqival<=160){
        _color='#43ce17';
        _quality="优";
        _iconUrl='assets/img/map/green.png';
    }
    else if(aqival<=200){
        _color='#efdc31';
        _quality="良";
        _iconUrl='assets/img/map/yellow.png';
    }
    else if(aqival<=300){
        _color='#fa0';
        _quality="轻度";
        _iconUrl='assets/img/map/orange.png';
    }
    else if(aqival<=400){
        _color='#ff401a';
        _quality="中度";
        _iconUrl='assets/img/map/red.png';
    }
    else if(aqival<=800){
        _color='#d20040';
        _quality="重度";
        _iconUrl='assets/img/map/violet.png';
    }
    else{
        _color='#9c0a4e';
        _quality="严重";
        _iconUrl='assets/img/map/black.png';
    }
    return {
        color:_color,
        quality:_quality,
        iconUrl:_iconUrl
    };
};
function getNo2Color(aqival){
    var _color=null;
    var _quality=null;
    var _iconUrl=null;
    if(aqival<=0 || isNaN(aqival)){
        _color='#6E6E6E';
        _quality="无";
        _iconUrl='assets/img/map/none.png';
    }
    else if(aqival<=100){
        _color='#43ce17';
        _quality="优";
        _iconUrl='assets/img/map/green.png';
    }
    else if(aqival<=200){
        _color='#efdc31';
        _quality="良";
        _iconUrl='assets/img/map/yellow.png';
    }
    else if(aqival<=700){
        _color='#fa0';
        _quality="轻度";
        _iconUrl='assets/img/map/orange.png';
    }
    else if(aqival<=1200){
        _color='#ff401a';
        _quality="中度";
        _iconUrl='assets/img/map/red.png';
    }
    else if(aqival<=2340){
        _color='#d20040';
        _quality="重度";
        _iconUrl='assets/img/map/violet.png';
    }
    else{
        _color='#9c0a4e';
        _quality="严重";
        _iconUrl='assets/img/map/black.png';
    }
    return {
        color:_color,
        quality:_quality,
        iconUrl:_iconUrl
    };
};
function getSo2Color(aqival){
    var _color=null;
    var _quality=null;
    var _iconUrl=null;
    if(aqival<=0 || isNaN(aqival)){
        _color='#6E6E6E';
        _quality="无";
        _iconUrl='assets/img/map/none.png';
    }
    else if(aqival<=50){
        _color='#43ce17';
        _quality="优";
        _iconUrl='assets/img/map/green.png';
    }
    else if(aqival<=150){
        _color='#efdc31';
        _quality="良";
        _iconUrl='assets/img/map/yellow.png';
    }
    else if(aqival<=475){
        _color='#fa0';
        _quality="轻度";
        _iconUrl='assets/img/map/orange.png';
    }
    else if(aqival<=800){
        _color='#ff401a';
        _quality="中度";
        _iconUrl='assets/img/map/red.png';
    }
    else if(aqival<=1600){
        _color='#d20040';
        _quality="重度";
        _iconUrl='assets/img/map/violet.png';
    }
    else{
        _color='#9c0a4e';
        _quality="严重";
        _iconUrl='assets/img/map/black.png';
    }
    return {
        color:_color,
        quality:_quality,
        iconUrl:_iconUrl
    };
};
function getEhiColor(aqival){
    var _color=null;
    var _quality=null;
    if(aqival<=0 || isNaN(aqival)){
        _color='#6E6E6E';
        _quality="无";
    }
    else if(aqival<=30){
        _color='#7E0023';
        _quality="严重";
    }
    else if(aqival<=50){
        _color='#99004C';
        _quality="重度";
    }
    else if(aqival<=70){
        _color='#ff0000';
        _quality="中度";
    }
    else if(aqival<=80){
        _color='#ff7e00';
        _quality="轻度";
    }
    else if(aqival<=90){
        _color='#ffff00';
        _quality="良";
    }
    else{
        _color='#00E400';
        _quality="优";
    }
    return {
        color:_color,
        quality:_quality
    };
};
function getWdColor(aqival){
    var _color=null;
    var _quality=null;
    var _iconUrl=null;
    if(isNaN(aqival)){
        _color='#6E6E6E';
        _quality="无";
        _iconUrl='assets/img/map/none.png';
    }else if(aqival<=5){
        _color='#0096FF';
        _quality="寒冷";
        _iconUrl='assets/img/map/red.png';
    }
    else if(aqival<=15){
        _color='#00E4FF';
        _quality="温凉";
        _iconUrl='assets/img/map/yellow.png';
    }
    else if(aqival<=20){
        _color='#FFE400';
        _quality="暖和";
        _iconUrl='assets/img/map/orange.png';
    }
    else if(aqival<=27){
        _color='#FFB400';
        _quality="舒适";
        _iconUrl='assets/img/map/green.png';
    }
    else if(aqival<=35){
        _color='#ff0000';
        _quality="炎热";
        _iconUrl='assets/img/map/violet.png';
    }
    else{
        _color='#99004C';
        _quality="奇热";
        _iconUrl='assets/img/map/black.png';
    }
    return {
        color:_color,
        quality:_quality,
        iconUrl:_iconUrl
    };
};
function getSdColor(aqival){
    var _color=null;
    var _quality=null;
    var _iconUrl=null;
    if(isNaN(aqival)){
        _color='#6E6E6E';
        _quality="无";
        _iconUrl='assets/img/map/none.png';
    }else if(aqival<=10){
        _color='#FF6400';
        _quality="极干";
        _iconUrl='assets/img/map/violet.png';
    }
    else if(aqival<=20){
        _color='#FFB400';
        _quality="干燥";
        _iconUrl='assets/img/map/red.png';
    }
    else if(aqival<=30){
        _color='#FFE400';
        _quality="较干";
        _iconUrl='assets/img/map/orange.png';
    }
    else if(aqival<=60){
        _color='#00E400';
        _quality="舒适";
        _iconUrl='assets/img/map/green.png';
    }
    else if(aqival<=80){
        _color='#00E4FF';
        _quality="湿润";
        _iconUrl='assets/img/map/violet.png';
    }
    else{
        _color='#0096FF';
        _quality="潮湿";
        _iconUrl='assets/img/map/black.png';
    }
    return {
        color:_color,
        quality:_quality,
        iconUrl:_iconUrl
    };
};
