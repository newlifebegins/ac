/**
 * Created by stormmys on 2017/4/9.
 */
var chart_scene_map = echarts.init(document.getElementById('scene_data_map'));
function scene_map() {
    chart_scene_map.showLoading();
    $.getJSON('./assets/js/shanxi.json', function (geoJson) {
        chart_scene_map.hideLoading();
        echarts.registerMap('shanxi', geoJson);
        chart_scene_map.setOption({
            title: {
                text: '景区分布',
                subtext: '数据来自yzdm',
                // sublink: 'http://zh.wikipedia.org/wiki/%E9%A6%99%E6%B8%AF%E8%A1%8C%E6%94%BF%E5%8D%80%E5%8A%83#cite_note-12'
            },
            tooltip: {
                trigger: 'item',
                formatter: '{b}<br/>{c} (p / km2)'
            },
            toolbox: {
                show: false,
                orient: 'vertical',
                left: 'right',
                top: 'center',
                feature: {
                    dataView: {readOnly: false},
                    restore: {},
                    saveAsImage: {}
                }
            },
            visualMap: {
                min: 800,
                max: 50000,
                text:['High','Low'],
                realtime: false,
                calculable: true,
                inRange: {
                    color: ['lightskyblue','yellow', 'orangered']
                }
            },
            series: [
                {
                    name: '山西景区分布',
                    type: 'map',
                    map: 'shanxi', // 自定义扩展图表类型
                    itemStyle:{
                        normal:{label:{show:true}},
                        emphasis:{label:{show:true}}
                    },
                    data:[
                        {name: '太原市', value: 11},
                        {name: '大同市', value: 15},
                        {name: '阳泉市', value: 4},
                        {name: '长治市', value: 3},
                        {name: '晋城市', value: 9},
                        {name: '朔州市', value: 4},
                        {name: '晋中市', value: 1},
                        {name: '运城市', value: 1},
                        {name: '忻州市', value: 5},
                        {name: '临汾市', value: 6},
                        {name: '吕梁市', value: 76}
                    ],
                    // 自定义名称映射
                    /*
                    nameMap: {
                        'Central and Western': '中西区',
                        'Eastern': '东区',
                        'Islands': '离岛',
                        'Kowloon City': '九龙城',
                        'Kwai Tsing': '葵青',
                        'Kwun Tong': '观塘',
                        'North': '北区',
                        'Sai Kung': '西贡',
                        'Sha Tin': '沙田',
                        'Sham Shui Po': '深水埗',
                        'Southern': '南区',
                        'Tai Po': '大埔',
                        'Tsuen Wan': '荃湾',
                        'Tuen Mun': '屯门',
                        'Wan Chai': '湾仔',
                        'Wong Tai Sin': '黄大仙',
                        'Yau Tsim Mong': '油尖旺',
                        'Yuen Long': '元朗'
                    }
                    */
                }
            ]
        });
    });
}
/*
var chart_scene_bar = echarts.init(document.getElementById('scene_data_bar'));
function scene_bar() {
    option = {
        // title: {
        //     text: '景区类型',
        //     subtext: '数据来自网络'
        // },
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'shadow'
            }
        },
        // legend: {
        //     data: ['2011年', '2012年']
        // },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'value',
            boundaryGap: [0, 0.01]
        },
        yAxis: {
            type: 'category',
            data: ['人文','风景','宗教','亲子','山水']
        },
        series: [
            {
                name: '景区总量',
                type: 'bar',
                data: [12, 30, 1, 40, 18]
            }
        ]
    }
    // 使用刚指定的配置项和数据显示图表。
    chart_scene_bar.setOption(option);
}

var chart_scene_pie = echarts.init(document.getElementById('scene_data_pie'));
function scene_pie() {
    option = {
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        legend: {
            orient: 'vertical',
            x: 'left',
            data:['人文','风景','宗教','亲子','山水']
        },
        series: [
            {
                name:'景区类型',
                type:'pie',
                radius: ['50%', '70%'],
                avoidLabelOverlap: false,
                label: {
                    normal: {
                        show: false,
                        position: 'center'
                    },
                    emphasis: {
                        show: true,
                        textStyle: {
                            fontSize: '30',
                            fontWeight: 'bold'
                        }
                    }
                },
                labelLine: {
                    normal: {
                        show: false
                    }
                },
                data:[
                    {value:12, name:'人文'},
                    {value:30, name:'风景'},
                    {value:1, name:'宗教'},
                    {value:40, name:'亲子'},
                    {value:18, name:'山水'}
                ]
            }
        ]
    };
    // 使用刚指定的配置项和数据显示图表。
    chart_scene_pie.setOption(option);
}
*/
function scene_liuliang() {
    var dataMap = {};
    function dataFormatter(obj) {
        var pList = ['00:00','02:00','04:00','06:00','08:00','10:00','12:00','14:00','16:00','18:00','20:00','22:00'];
        var temp;
        for (var year = 2002; year <= 2008; year++) {
            var max = 0;
            var sum = 0;
            temp = obj[year];
            for (var i = 0, l = temp.length; i < l; i++) {
                max = Math.max(max, temp[i]);
                sum += temp[i];
                obj[year][i] = {
                    name : pList[i],
                    value : temp[i]
                }
            }
            obj[year + 'max'] = Math.floor(max / 100) * 100;
            obj[year + 'sum'] = sum;
        }
        return obj;
    }

    dataMap.dataNO2 = dataFormatter({
        //max : 60000,
        2008:[32, 34, 38, 48, 64, 54, 45, 27, 20, 23, 34, 59],
        2007:[64, 70, 74, 71, 66, 46, 28, 16, 15, 24, 39, 45],
        2006:[44, 55, 74, 73, 80, 68, 69, 25, 20, 25, 40, 52],
        2005:[41, 46, 45, 53, 71, 59, 25, 15, 18, 23, 32, 41],
        2004:[38, 45, 41, 48, 62, 38, 26, 20, 19, 25, 36, 46],
        2003:[33, 38, 31, 34, 39, 31, 26, 21, 24, 32, 41, 28],
        2002:[22, 29, 32, 28, 30, 23, 19, 16, 18, 20, 32, 43]
    });

    dataMap.dataPI = dataFormatter({
        //max : 4000,
        2008:[38, 37, 40, 45, 48, 46, 48, 38, 29, 32, 34, 39],
        2007:[47, 50, 48, 47, 50, 44, 40, 30, 17, 21, 24, 28],
        2006:[31, 34, 38, 35, 42, 32, 39, 33, 36, 33, 42, 50],
        2005:[58, 61, 62, 61, 61, 69, 63, 47, 49, 58, 56, 56],
        2004:[58, 61, 63, 67, 77, 75, 74, 76, 85, 80, 107, 125],
        2003:[95, 86, 70, 69, 71, 77, 80, 75, 67, 72, 71, 55],
        2002:[45, 44, 40, 35, 34, 31, 29, 32, 33, 31, 35, 49]
    });

    dataMap.dataSI = dataFormatter({
        //max : 26600,
        2008:[67, 61, 57, 68, 84, 76, 60, 51, 39, 41, 53, 83],
        2007:[71, 69, 61, 69, 74, 73, 55, 37, 28, 41, 61, 82],
        2006:[81, 79, 89, 97, 94, 87, 87, 55, 56, 70, 116, 139],
        2005:[128, 134, 128, 122, 135, 163, 98, 85, 104, 136, 139, 132],
        2004:[135, 135, 129, 129, 153, 139, 146, 146, 154, 158, 187, 231],
        2003:[166, 138, 124, 135, 130, 140, 143, 133, 161, 121, 82, 72],
        2002:[57, 55, 49, 46, 49, 44, 45, 44, 64, 54, 80, 106]
    });

    dataMap.dataTI = dataFormatter({
        //max : 25000,
        2008:[10, 8, 7, 6, 6, 5, 5, 4, 4, 3, 3, 3],
        2007:[3, 4, 3, 3, 4, 4, 4, 2, 2, 2, 2, 3],
        2006:[3, 3, 9, 3, 10, 4, 4, 3, 2, 3, 4, 6],
        2005:[7, 7, 6, 5, 7, 9, 7, 5, 6, 9, 6, 5],
        2004:[5, 5, 7, 7, 11, 14, 16, 16, 15, 13, 11, 10],
        2003:[7, 6, 15, 16, 15, 18, 22, 21, 12, 3, 3, 2],
        2002:[2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 4]
    });

    dataMap.dataEstate = dataFormatter({
        //max : 3600,
        2008:[95, 88, 77, 62, 51, 62, 90, 133, 166, 158, 137, 78],
        2007:[49, 30, 34, 27, 61, 123, 203, 189, 170, 154, 123, 109],
        2006:[89, 62, 43, 20, 39, 88, 148, 240, 228, 205, 186, 127],
        2005:[141, 110, 82, 68, 68, 161, 227, 213, 228, 233, 199, 147],
        2004:[124, 100, 91, 73, 79, 174, 231, 267, 291, 266, 222, 173],
        2003:[157, 113, 96, 87, 97, 166, 260, 302, 261, 174, 155, 151],
        2002:[136, 106, 81, 76, 80, 121, 174, 216, 239, 214, 185, 148]
    });

    dataMap.dataEstate1 = dataFormatter({
        //max : 3600,
        2008:[59, 56, 57, 63, 68, 64, 66, 54, 58, 50, 52, 67],
        2007:[66, 70, 66, 65, 70, 62, 102, 86, 63, 49, 56, 67],
        2006:[66, 65, 70, 74, 72, 69, 69, 121, 115, 103, 84, 95],
        2005:[90, 92, 90, 87, 93, 107, 114, 107, 115, 117, 99, 92],
        2004:[93, 93, 90, 91, 103, 101, 116, 134, 146, 133, 141, 164],
        2003:[126, 115, 94, 93, 95, 102, 130, 151, 131, 96, 96, 76],
        2002:[63, 61, 57, 50, 49, 44, 68, 109, 120, 107, 81, 78]
    });




    option = {
        baseOption: {
            timeline: {
                // y: 0,
                axisType: 'category',
                // realtime: false,
                // loop: false,
                autoPlay: true,
                // currentIndex: 2,
                playInterval: 2000,
                // controlStyle: {
                //     position: 'left'
                // },
                data: [
                    '6月12日','6月13日','6月14日',

                    '6月15日','6月16日', '6月17日','6月18日',
                ],
                label: {
                    formatter : function(s) {
                        return s;
                    }
                }
            },
            title: {
               // subtext: '数据来自罗克佳华'
            },
            tooltip: {
            },
            legend: {
                x: 'right',
                data: ['PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'AQI'],
                selected: {
                    // 'NO2': false, 'CO': false, 'AQI': false
                }
            },
            calculable : true,
            grid: {
                top: 80,
                bottom: 100,
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow',
                        label: {
                            show: true,
                            formatter: function (params) {
                                return params.value.replace('\n', '');
                            }
                        }
                    }
                }
            },
            xAxis: [
                {
                    'type':'category',
                    'axisLabel':{'interval':0},
                    'data':[
                        '00:00','02:00','04:00','06:00','08:00','10:00','12:00','14:00','16:00','18:00','20:00','22:00'
                    ],
                    splitLine: {show: false}
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '浓度 (ug/m3)',

                    axisLabel: {
                        formatter: '{value}'
                    }
                },
                {
                    type: 'value',
                    name: 'AQI',

                    axisLabel: {
                        formatter: '{value} '
                    }
                }
            ],
            series: [
                {name: 'NO2', type: 'bar'},
                //{name: 'CO', type: 'bar'},
                {name: 'O3', type: 'bar'},
                {name: 'AQI', type: 'line',yAxisIndex: 1},
                {name: 'PM2.5', type: 'bar'},
                {name: 'PM10', type: 'bar'},
                {name: 'SO2', type: 'bar'},

            ]
        },
        options: [
            {
               // title: {text: '北京市近一周空气环境综合指数'},
                series: [
                    {data: dataMap.dataNO2['2002']},
                    // {data: dataMap.dataFinancial['2002']},
                    {data: dataMap.dataEstate['2002']},
                    {data: dataMap.dataEstate1['2002']},
                    {data: dataMap.dataPI['2002']},
                    {data: dataMap.dataSI['2002']},
                    {data: dataMap.dataTI['2002']},

                ]
            },
            {

                series : [
                    {data: dataMap.dataNO2['2003']},
                    // {data: dataMap.dataFinancial['2003']},
                    {data: dataMap.dataEstate['2003']},
                    {data: dataMap.dataEstate1['2003']},
                    {data: dataMap.dataPI['2003']},
                    {data: dataMap.dataSI['2003']},
                    {data: dataMap.dataTI['2003']},

                ]
            },
            {

                series : [
                    {data: dataMap.dataNO2['2004']},
                    // {data: dataMap.dataFinancial['2004']},
                    {data: dataMap.dataEstate['2004']},
                    {data: dataMap.dataEstate1['2004']},
                    {data: dataMap.dataPI['2004']},
                    {data: dataMap.dataSI['2004']},
                    {data: dataMap.dataTI['2004']},

                ]
            },
            {

                series : [
                    {data: dataMap.dataNO2['2005']},
                    // {data: dataMap.dataFinancial['2005']},
                    {data: dataMap.dataEstate['2005']},
                    {data: dataMap.dataEstate1['2005']},
                    {data: dataMap.dataPI['2005']},
                    {data: dataMap.dataSI['2005']},
                    {data: dataMap.dataTI['2005']},

                ]
            },
            {

                series : [
                    {data: dataMap.dataNO2['2006']},
                    //  {data: dataMap.dataFinancial['2006']},
                    {data: dataMap.dataEstate['2006']},
                    {data: dataMap.dataEstate1['2006']},
                    {data: dataMap.dataPI['2006']},
                    {data: dataMap.dataSI['2006']},
                    {data: dataMap.dataTI['2006']},

                ]
            },
            {

                series : [
                    {data: dataMap.dataNO2['2007']},
                    //  {data: dataMap.dataFinancial['2007']},
                    {data: dataMap.dataEstate['2007']},
                    {data: dataMap.dataEstate1['2007']},
                    {data: dataMap.dataPI['2007']},
                    {data: dataMap.dataSI['2007']},
                    {data: dataMap.dataTI['2007']},

                ]
            },
            {

                series : [
                    {data: dataMap.dataNO2['2008']},
                    //  {data: dataMap.dataFinancial['2008']},
                    {data: dataMap.dataEstate['2008']},
                    {data: dataMap.dataEstate1['2008']},
                    {data: dataMap.dataPI['2008']},
                    {data: dataMap.dataSI['2008']},
                    {data: dataMap.dataTI['2008']},

                ]
            },

        ]
    };
    chart_scene_map.setOption(option);
}

var chart_real_time_aqi= echarts.init(document.getElementById('real_time_aqi'));
function real_time_aqi() {

    var geoCoordMap = {
        "海门":[121.15,31.89],
        "鄂尔多斯":[109.781327,39.608266],
        "招远":[120.38,37.35],
        "舟山":[122.207216,29.985295],
        "齐齐哈尔":[123.97,47.33],
        "盐城":[120.13,33.38],
        "赤峰":[118.87,42.28],
        "青岛":[120.33,36.07],
        "乳山":[121.52,36.89],
        "金昌":[102.188043,38.520089],
        "泉州":[118.58,24.93],
        "莱西":[120.53,36.86],
        "日照":[119.46,35.42],
        "胶南":[119.97,35.88],
        "南通":[121.05,32.08],
        "拉萨":[91.11,29.97],
        "云浮":[112.02,22.93],
        "梅州":[116.1,24.55],
        "文登":[122.05,37.2],
        "上海":[121.48,31.22],
        "攀枝花":[101.718637,26.582347],
        "威海":[122.1,37.5],
        "承德":[117.93,40.97],
        "厦门":[118.1,24.46],
        "汕尾":[115.375279,22.786211],
        "潮州":[116.63,23.68],
        "丹东":[124.37,40.13],
        "太仓":[121.1,31.45],
        "曲靖":[103.79,25.51],
        "烟台":[121.39,37.52],
        "福州":[119.3,26.08],
        "瓦房店":[121.979603,39.627114],
        "即墨":[120.45,36.38],
        "抚顺":[123.97,41.97],
        "玉溪":[102.52,24.35],
        "张家口":[114.87,40.82],
        "阳泉":[113.57,37.85],
        "莱州":[119.942327,37.177017],
        "湖州":[120.1,30.86],
        "汕头":[116.69,23.39],
        "昆山":[120.95,31.39],
        "宁波":[121.56,29.86],
        "湛江":[110.359377,21.270708],
        "揭阳":[116.35,23.55],
        "荣成":[122.41,37.16],
        "连云港":[119.16,34.59],
        "葫芦岛":[120.836932,40.711052],
        "常熟":[120.74,31.64],
        "东莞":[113.75,23.04],
        "河源":[114.68,23.73],
        "淮安":[119.15,33.5],
        "泰州":[119.9,32.49],
        "南宁":[108.33,22.84],
        "营口":[122.18,40.65],
        "惠州":[114.4,23.09],
        "江阴":[120.26,31.91],
        "蓬莱":[120.75,37.8],
        "韶关":[113.62,24.84],
        "嘉峪关":[98.289152,39.77313],
        "广州":[113.23,23.16],
        "延安":[109.47,36.6],
        "太原":[112.53,37.87],
        "清远":[113.01,23.7],
        "中山":[113.38,22.52],
        "昆明":[102.73,25.04],
        "寿光":[118.73,36.86],
        "盘锦":[122.070714,41.119997],
        "长治":[113.08,36.18],
        "深圳":[114.07,22.62],
        "珠海":[113.52,22.3],
        "宿迁":[118.3,33.96],
        "咸阳":[108.72,34.36],
        "铜川":[109.11,35.09],
        "平度":[119.97,36.77],
        "佛山":[113.11,23.05],
        "海口":[110.35,20.02],
        "江门":[113.06,22.61],
        "章丘":[117.53,36.72],
        "肇庆":[112.44,23.05],
        "大连":[121.62,38.92],
        "临汾":[111.5,36.08],
        "吴江":[120.63,31.16],
        "石嘴山":[106.39,39.04],
        "沈阳":[123.38,41.8],
        "苏州":[120.62,31.32],
        "茂名":[110.88,21.68],
        "嘉兴":[120.76,30.77],
        "长春":[125.35,43.88],
        "胶州":[120.03336,36.264622],
        "银川":[106.27,38.47],
        "张家港":[120.555821,31.875428],
        "三门峡":[111.19,34.76],
        "锦州":[121.15,41.13],
        "南昌":[115.89,28.68],
        "柳州":[109.4,24.33],
        "三亚":[109.511909,18.252847],
        "自贡":[104.778442,29.33903],
        "吉林":[126.57,43.87],
        "阳江":[111.95,21.85],
        "泸州":[105.39,28.91],
        "西宁":[101.74,36.56],
        "宜宾":[104.56,29.77],
        "呼和浩特":[111.65,40.82],
        "成都":[104.06,30.67],
        "大同":[113.3,40.12],
        "镇江":[119.44,32.2],
        "桂林":[110.28,25.29],
        "张家界":[110.479191,29.117096],
        "宜兴":[119.82,31.36],
        "北海":[109.12,21.49],
        "西安":[108.95,34.27],
        "金坛":[119.56,31.74],
        "东营":[118.49,37.46],
        "牡丹江":[129.58,44.6],
        "遵义":[106.9,27.7],
        "绍兴":[120.58,30.01],
        "扬州":[119.42,32.39],
        "常州":[119.95,31.79],
        "潍坊":[119.1,36.62],
        "重庆":[106.54,29.59],
        "台州":[121.420757,28.656386],
        "南京":[118.78,32.04],
        "滨州":[118.03,37.36],
        "贵阳":[106.71,26.57],
        "无锡":[120.29,31.59],
        "本溪":[123.73,41.3],
        "克拉玛依":[84.77,45.59],
        "渭南":[109.5,34.52],
        "马鞍山":[118.48,31.56],
        "宝鸡":[107.15,34.38],
        "焦作":[113.21,35.24],
        "句容":[119.16,31.95],
        "北京":[116.46,39.92],
        "徐州":[117.2,34.26],
        "衡水":[115.72,37.72],
        "包头":[110,40.58],
        "绵阳":[104.73,31.48],
        "乌鲁木齐":[87.68,43.77],
        "枣庄":[117.57,34.86],
        "杭州":[120.19,30.26],
        "淄博":[118.05,36.78],
        "鞍山":[122.85,41.12],
        "溧阳":[119.48,31.43],
        "库尔勒":[86.06,41.68],
        "安阳":[114.35,36.1],
        "开封":[114.35,34.79],
        "济南":[117,36.65],
        "德阳":[104.37,31.13],
        "温州":[120.65,28.01],
        "九江":[115.97,29.71],
        "邯郸":[114.47,36.6],
        "临安":[119.72,30.23],
        "兰州":[103.73,36.03],
        "沧州":[116.83,38.33],
        "临沂":[118.35,35.05],
        "南充":[106.110698,30.837793],
        "天津":[117.2,39.13],
        "富阳":[119.95,30.07],
        "泰安":[117.13,36.18],
        "诸暨":[120.23,29.71],
        "郑州":[113.65,34.76],
        "哈尔滨":[126.63,45.75],
        "聊城":[115.97,36.45],
        "芜湖":[118.38,31.33],
        "唐山":[118.02,39.63],
        "平顶山":[113.29,33.75],
        "邢台":[114.48,37.05],
        "德州":[116.29,37.45],
        "济宁":[116.59,35.38],
        "荆州":[112.239741,30.335165],
        "宜昌":[111.3,30.7],
        "义乌":[120.06,29.32],
        "丽水":[119.92,28.45],
        "洛阳":[112.44,34.7],
        "秦皇岛":[119.57,39.95],
        "株洲":[113.16,27.83],
        "石家庄":[114.48,38.03],
        "莱芜":[117.67,36.19],
        "常德":[111.69,29.05],
        "保定":[115.48,38.85],
        "湘潭":[112.91,27.87],
        "金华":[119.64,29.12],
        "岳阳":[113.09,29.37],
        "长沙":[113,28.21],
        "衢州":[118.88,28.97],
        "廊坊":[116.7,39.53],
        "菏泽":[115.480656,35.23375],
        "合肥":[117.27,31.86],
        "武汉":[114.31,30.52],
        "大庆":[125.03,46.58]
    };

    var data = [
        {name: "海门", value: 9},
        {name: "鄂尔多斯", value: 12},
        {name: "招远", value: 12},
        {name: "舟山", value: 12},
        {name: "齐齐哈尔", value: 14},
        {name: "盐城", value: 15},
        {name: "赤峰", value: 16},
        {name: "青岛", value: 18},
        {name: "乳山", value: 18},
        {name: "金昌", value: 19},
        {name: "泉州", value: 21},
        {name: "莱西", value: 21},
        {name: "日照", value: 21},
        {name: "胶南", value: 22},
        {name: "南通", value: 23},
        {name: "拉萨", value: 24},
        {name: "云浮", value: 24},
        {name: "梅州", value: 25},
        {name: "文登", value: 25},
        {name: "上海", value: 25},
        {name: "攀枝花", value: 25},
        {name: "威海", value: 25},
        {name: "承德", value: 25},
        {name: "厦门", value: 26},
        {name: "汕尾", value: 26},
        {name: "潮州", value: 26},
        {name: "丹东", value: 27},
        {name: "太仓", value: 27},
        {name: "曲靖", value: 27},
        {name: "烟台", value: 28},
        {name: "福州", value: 29},
        {name: "瓦房店", value: 30},
        {name: "即墨", value: 30},
        {name: "抚顺", value: 31},
        {name: "玉溪", value: 31},
        {name: "张家口", value: 31},
        {name: "阳泉", value: 31},
        {name: "莱州", value: 32},
        {name: "湖州", value: 32},
        {name: "汕头", value: 32},
        {name: "昆山", value: 33},
        {name: "宁波", value: 33},
        {name: "湛江", value: 33},
        {name: "揭阳", value: 34},
        {name: "荣成", value: 34},
        {name: "连云港", value: 35},
        {name: "葫芦岛", value: 35},
        {name: "常熟", value: 36},
        {name: "东莞", value: 36},
        {name: "河源", value: 36},
        {name: "淮安", value: 36},
        {name: "泰州", value: 36},
        {name: "南宁", value: 37},
        {name: "营口", value: 37},
        {name: "惠州", value: 37},
        {name: "江阴", value: 37},
        {name: "蓬莱", value: 37},
        {name: "韶关", value: 38},
        {name: "嘉峪关", value: 38},
        {name: "广州", value: 38},
        {name: "延安", value: 38},
        {name: "太原", value: 39},
        {name: "清远", value: 39},
        {name: "中山", value: 39},
        {name: "昆明", value: 39},
        {name: "寿光", value: 40},
        {name: "盘锦", value: 40},
        {name: "长治", value: 41},
        {name: "深圳", value: 41},
        {name: "珠海", value: 42},
        {name: "宿迁", value: 43},
        {name: "咸阳", value: 43},
        {name: "铜川", value: 44},
        {name: "平度", value: 44},
        {name: "佛山", value: 44},
        {name: "海口", value: 44},
        {name: "江门", value: 45},
        {name: "章丘", value: 45},
        {name: "肇庆", value: 46},
        {name: "大连", value: 47},
        {name: "临汾", value: 47},
        {name: "吴江", value: 47},
        {name: "石嘴山", value: 49},
        {name: "沈阳", value: 50},
        {name: "苏州", value: 50},
        {name: "茂名", value: 50},
        {name: "嘉兴", value: 51},
        {name: "长春", value: 51},
        {name: "胶州", value: 52},
        {name: "银川", value: 52},
        {name: "张家港", value: 52},
        {name: "三门峡", value: 53},
        {name: "锦州", value: 54},
        {name: "南昌", value: 54},
        {name: "柳州", value: 54},
        {name: "三亚", value: 54},
        {name: "自贡", value: 56},
        {name: "吉林", value: 56},
        {name: "阳江", value: 57},
        {name: "泸州", value: 57},
        {name: "西宁", value: 57},
        {name: "宜宾", value: 58},
        {name: "呼和浩特", value: 58},
        {name: "成都", value: 58},
        {name: "大同", value: 58},
        {name: "镇江", value: 59},
        {name: "桂林", value: 59},
        {name: "张家界", value: 59},
        {name: "宜兴", value: 59},
        {name: "北海", value: 60},
        {name: "西安", value: 61},
        {name: "金坛", value: 62},
        {name: "东营", value: 62},
        {name: "牡丹江", value: 63},
        {name: "遵义", value: 63},
        {name: "绍兴", value: 63},
        {name: "扬州", value: 64},
        {name: "常州", value: 64},
        {name: "潍坊", value: 65},
        {name: "重庆", value: 66},
        {name: "台州", value: 67},
        {name: "南京", value: 67},
        {name: "滨州", value: 70},
        {name: "贵阳", value: 71},
        {name: "无锡", value: 71},
        {name: "本溪", value: 71},
        {name: "克拉玛依", value: 72},
        {name: "渭南", value: 72},
        {name: "马鞍山", value: 72},
        {name: "宝鸡", value: 72},
        {name: "焦作", value: 75},
        {name: "句容", value: 75},
        {name: "北京", value: 79},
        {name: "徐州", value: 79},
        {name: "衡水", value: 80},
        {name: "包头", value: 80},
        {name: "绵阳", value: 80},
        {name: "乌鲁木齐", value: 84},
        {name: "枣庄", value: 84},
        {name: "杭州", value: 84},
        {name: "淄博", value: 85},
        {name: "鞍山", value: 86},
        {name: "溧阳", value: 86},
        {name: "库尔勒", value: 86},
        {name: "安阳", value: 90},
        {name: "开封", value: 90},
        {name: "济南", value: 92},
        {name: "德阳", value: 93},
        {name: "温州", value: 95},
        {name: "九江", value: 96},
        {name: "邯郸", value: 98},
        {name: "临安", value: 99},
        {name: "兰州", value: 99},
        {name: "沧州", value: 100},
        {name: "临沂", value: 103},
        {name: "南充", value: 104},
        {name: "天津", value: 105},
        {name: "富阳", value: 106},
        {name: "泰安", value: 112},
        {name: "诸暨", value: 112},
        {name: "郑州", value: 113},
        {name: "哈尔滨", value: 114},
        {name: "聊城", value: 116},
        {name: "芜湖", value: 117},
        {name: "唐山", value: 119},
        {name: "平顶山", value: 119},
        {name: "邢台", value: 119},
        {name: "德州", value: 120},
        {name: "济宁", value: 120},
        {name: "荆州", value: 127},
        {name: "宜昌", value: 130},
        {name: "义乌", value: 132},
        {name: "丽水", value: 133},
        {name: "洛阳", value: 134},
        {name: "秦皇岛", value: 136},
        {name: "株洲", value: 143},
        {name: "石家庄", value: 147},
        {name: "莱芜", value: 148},
        {name: "常德", value: 152},
        {name: "保定", value: 153},
        {name: "湘潭", value: 154},
        {name: "金华", value: 157},
        {name: "岳阳", value: 169},
        {name: "长沙", value: 175},
        {name: "衢州", value: 177},
        {name: "廊坊", value: 193},
        {name: "菏泽", value: 194},
        {name: "合肥", value: 229},
        {name: "武汉", value: 273},
        {name: "大庆", value: 279}
    ];

    var convertData = function (data) {
        var res = [];
        for (var i = 0; i < data.length; i++) {
            var geoCoord = geoCoordMap[data[i].name];
            if (geoCoord) {
                res.push({
                    name: data[i].name,
                    value: geoCoord.concat(data[i].value)
                });
            }
        }
        return res;
    };

    var convertedData = [
        convertData(data),
        convertData(data.sort(function (a, b) {
            return b.value - a.value;
        }).slice(0, 6))
    ];

    $.getJSON('./assets/js/china.json', function (geoJson) {
        echarts.registerMap('china', geoJson);
        option = {
            backgroundColor: '#404a59',
            animation: true,
            animationDuration: 1000,
            animationEasing: 'cubicInOut',
            animationDurationUpdate: 1000,
            animationEasingUpdate: 'cubicInOut',
            title: [
                {
                    text: '全国主要城市 PM 2.5',
                    subtext: 'data from PM25.in',
                    sublink: 'http://www.pm25.in',
                    left: 'center',
                    textStyle: {
                        color: '#fff'
                    }
                },
                {
                    id: 'statistic',
                    right: 120,
                    top: 40,
                    width: 100,
                    textStyle: {
                        color: '#fff',
                        fontSize: 16
                    }
                }
            ],
            toolbox: {
                iconStyle: {
                    normal: {
                        borderColor: '#fff'
                    },
                    emphasis: {
                        borderColor: '#b1e4ff'
                    }
                }
            },
            brush: {
                outOfBrush: {
                    color: '#abc'
                },
                brushStyle: {
                    borderWidth: 2,
                    color: 'rgba(0,0,0,0.2)',
                    borderColor: 'rgba(0,0,0,0.5)',
                },
                seriesIndex: [0, 1],
                throttleType: 'debounce',
                throttleDelay: 300,
                geoIndex: 0
            },
            geo: {
                map: 'china',
                left: '10',
                right: '35%',
                center: [117.98561551896913, 32.205000490896193],
                zoom: 2.5,
                label: {
                    emphasis: {
                        show: false
                    }
                },
                roam: true,
                itemStyle: {
                    normal: {
                        areaColor: '#323c48',
                        borderColor: '#111'
                    },
                    emphasis: {
                        areaColor: '#2a333d'
                    }
                }
            },
            tooltip: {
                trigger: 'item'
            },
            grid: {
                right: 40,
                top: 100,
                bottom: 40,
                width: '30%'
            },
            xAxis: {
                type: 'value',
                scale: true,
                position: 'top',
                boundaryGap: false,
                splitLine: {show: false},
                axisLine: {show: false},
                axisTick: {show: false},
                axisLabel: {margin: 2, textStyle: {color: '#aaa'}},
            },
            yAxis: {
                type: 'category',
                name: 'TOP 20',
                nameGap: 16,
                axisLine: {show: false, lineStyle: {color: '#ddd'}},
                axisTick: {show: false, lineStyle: {color: '#ddd'}},
                axisLabel: {interval: 0, textStyle: {color: '#ddd'}},
                data: []
            },
            series: [
                {
                    name: 'pm2.5',
                    type: 'scatter',
                    coordinateSystem: 'geo',
                    data: convertedData[0],
                    symbolSize: function (val) {
                        return Math.max(val[2] / 10, 8);
                    },
                    label: {
                        normal: {
                            formatter: '{b}',
                            position: 'right',
                            show: false
                        },
                        emphasis: {
                            show: true
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: '#ddb926'
                        }
                    }
                },
                {
                    name: 'Top 5',
                    type: 'effectScatter',
                    coordinateSystem: 'geo',
                    data: convertedData[1],
                    symbolSize: function (val) {
                        return Math.max(val[2] / 10, 8);
                    },
                    showEffectOn: 'emphasis',
                    rippleEffect: {
                        brushType: 'stroke'
                    },
                    hoverAnimation: true,
                    label: {
                        normal: {
                            formatter: '{b}',
                            position: 'right',
                            show: true
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: '#f4e925',
                            shadowBlur: 10,
                            shadowColor: '#333'
                        }
                    },
                    zlevel: 1
                },
                {
                    id: 'bar',
                    zlevel: 2,
                    type: 'bar',
                    symbol: 'none',
                    itemStyle: {
                        normal: {
                            color: '#ddb926'
                        }
                    },
                    data: []
                }
            ]
        };
        chart_real_time_aqi.setOption(option);
        setTimeout(function () {
            chart_real_time_aqi.dispatchAction({
                type: 'brush',
                areas: [
                    {
                        geoIndex: 0,
                        brushType: 'polygon',
                        coordRange: [[109.72,34.85],[108.68,38.85],[117.5,41.84],[119.19,34.77]]
                    }
                ]
            });
        }, 0);
    });
    chart_real_time_aqi.on('brushselected', renderBrushed);

    function renderBrushed(params) {
        var mainSeries = params.batch[0].selected[0];

        var selectedItems = [];
        var categoryData = [];
        var barData = [];
        var maxBar = 30;
        var sum = 0;
        var count = 0;

        for (var i = 0; i < mainSeries.dataIndex.length; i++) {
            var rawIndex = mainSeries.dataIndex[i];
            var dataItem = convertedData[0][rawIndex];
            var pmValue = dataItem.value[2];

            sum += pmValue;
            count++;

            selectedItems.push(dataItem);
        }

        selectedItems.sort(function (a, b) {
            return a.value[2] - b.value[2];
        });

        for (var i = 0; i < Math.min(selectedItems.length, maxBar); i++) {
            categoryData.push(selectedItems[i].name);
            barData.push(selectedItems[i].value[2]);
        }

        this.setOption({
            yAxis: {
                data: categoryData
            },
            xAxis: {
                axisLabel: {show: !!count}
            },
            title: {
                id: 'statistic',
                text: count ? '平均: ' + (sum / count).toFixed(4) : ''
            },
            series: {
                id: 'bar',
                data: barData
            }
        });
    }
}

var chart_source_star_map = echarts.init(document.getElementById('source_star_map'));
function source_star_map()
{
    chart_source_star_map.showLoading();
    $.get('./assets/js/weibo.json', function (weiboData)
    {
        chart_source_star_map.hideLoading();
        weiboData = weiboData.map(function (serieData, idx) {
            var px = serieData[0] / 1000;
            var py = serieData[1] / 1000;
            var res = [[px, py]];

            for (var i = 2; i < serieData.length; i += 2) {
                var dx = serieData[i] / 1000;
                var dy = serieData[i + 1] / 1000;
                var x = px + dx;
                var y = py + dy;
                res.push([x.toFixed(2), y.toFixed(2), 1]);

                px = x;
                py = y;
            }
            return res;
        });
        chart_source_star_map.setOption(option = {
            backgroundColor: '#404a59',
            title : {
                text: '重点污染源分布',
                subtext: '数据来自罗克佳华',

                left: 'center',
                top: 'top',
                textStyle: {
                    color: '#fff'
                }
            },
            tooltip: {},
            legend: {
                left: 'left',
                data: ['工业污染', '农业污染', '生活污染'],
                textStyle: {
                    color: '#ccc'
                }
            },
            geo: {
                map: 'china',
                label: {
                    emphasis: {
                        show: false
                    }
                },
                itemStyle: {
                    normal: {
                        areaColor: '#323c48',
                        borderColor: '#111'
                    },
                    emphasis: {
                        areaColor: '#2a333d'
                    }
                }
            },
            series: [{
                name: '生活污染',
                type: 'scatter',
                coordinateSystem: 'geo',
                symbolSize: 1,
                large: true,
                itemStyle: {
                    normal: {
                        shadowBlur: 2,
                        shadowColor: 'rgba(37, 140, 249, 0.8)',
                        color: 'rgba(37, 140, 249, 0.8)'
                    }
                },
                data: weiboData[0]
            }, {
                name: '农业污染',
                type: 'scatter',
                coordinateSystem: 'geo',
                symbolSize: 1,
                large: true,
                itemStyle: {
                    normal: {
                        shadowBlur: 2,
                        shadowColor: 'rgba(14, 241, 242, 0.8)',
                        color: 'rgba(14, 241, 242, 0.8)'
                    }
                },
                data: weiboData[1]
            }, {
                name: '工业污染',
                type: 'scatter',
                coordinateSystem: 'geo',
                symbolSize: 1,
                large: true,
                itemStyle: {
                    normal: {
                        shadowBlur: 2,
                        shadowColor: 'rgba(255, 255, 255, 0.8)',
                        color: 'rgba(255, 255, 255, 0.8)'
                    }
                },
                data: weiboData[2]
            }]
        });
    });
}

var chart_gongxian_pie = echarts.init(document.getElementById('gongxian_pie'));
function gongxian_pie() {
    option = {
        title : {
            text: '六项污染物贡献率分布',
            subtext: '数据来自罗克佳华',
            x:'center'
        },
        tooltip : {
            trigger: 'item',
            formatter: "{a} <br/>{b} : {c} ({d}%)"
        },
        legend: {
            x : 'center',
            y : 'bottom',
            data:['PM2.5','PM10','NO2','SO2','CO','O3']
        },
        toolbox: {
            show : false,
            feature : {
                mark : {show: true},
                dataView : {show: true, readOnly: false},
                magicType : {
                    show: true,
                    type: ['pie', 'funnel']
                },
                restore : {show: true},
                saveAsImage : {show: true}
            }
        },
        calculable : true,
        series : [
            {
                name:'面积模式',
                type:'pie',
                radius : [30, 110],

                roseType : 'area',
                data:[
                    {value:1.692, name:'PM2.5'},
                    {value:1.965, name:'PM10'},
                    {value:0.903, name:'NO2'},
                    {value:0.122, name:'SO2'},
                    {value:0.303, name:'CO'},
                    {value:1.564, name:'O3'}
                ]
            }
        ]
    };
    chart_gongxian_pie.setOption(option);
}

var chart_wuran_duibi_column = echarts.init(document.getElementById('wuran_duibi_column'));
function wuran_duibi_column() {
    option = {
        title: {
            // text: '城市污染对比',
            // subtext: '数据来自罗克佳华'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data:['北京','上海','太原']
        },
        toolbox: {
            show: false,
            feature: {
                dataZoom: {
                    yAxisIndex: 'none'
                },
                dataView: {readOnly: false},
                magicType: {type: ['line', 'bar']},
                restore: {},
                saveAsImage: {}
            }
        },
        xAxis:  {
            type: 'category',
            boundaryGap: false,
            data: ['6月14日','6月15日','6月16日','6月17日','6月18日','6月19日','6月20日']
        },
        yAxis: {
            type: 'value',
            axisLabel: {
                formatter: '{value} °C'
            }
        },
        series: [
            {
                name:'北京',
                type:'line',
                data:[120, 156, 158, 199, 187, 151, 155],
                markPoint: {
                    data: [
                        {type: 'max', name: '最大值'},
                        {type: 'min', name: '最小值'}
                    ]
                },
                markLine: {
                    data: [
                        {type: 'average', name: '平均值'},
                        [{
                            symbol: 'none',
                            x: '90%',
                            yAxis: 'max'
                        }, {
                            symbol: 'circle',
                            label: {
                                normal: {
                                    position: 'start',
                                    formatter: '最大值'
                                }
                            },
                            type: 'max',
                            name: '最高点'
                        }]
                    ]
                }
            },
            {
                name:'上海',
                type:'line',
                data:[60, 82, 87, 106, 67, 45, 47],
                markPoint: {
                    data: [
                        {type: 'max', name: '最大值'},
                        {type: 'min', name: '最小值'}
                    ]
                },
                markLine: {
                    data: [
                        {type: 'average', name: '平均值'},
                        [{
                            symbol: 'none',
                            x: '90%',
                            yAxis: 'max'
                        }, {
                            symbol: 'circle',
                            label: {
                                normal: {
                                    position: 'start',
                                    formatter: '最大值'
                                }
                            },
                            type: 'max',
                            name: '最高点'
                        }]
                    ]
                }
            },
            {
                name:'太原',
                type:'line',
                data:[149, 147, 185, 153, 137, 90, 96],
                markPoint: {
                    data: [
                        {type: 'max', name: '最大值'},
                        {type: 'min', name: '最小值'}
                    ]
                },
                markLine: {
                    data: [
                        {type: 'average', name: '平均值'},
                        [{
                            symbol: 'none',
                            x: '90%',
                            yAxis: 'max'
                        }, {
                            symbol: 'circle',
                            label: {
                                normal: {
                                    position: 'start',
                                    formatter: '最大值'
                                }
                            },
                            type: 'max',
                            name: '最高点'
                        }]
                    ]
                }
            }
        ]
    };
    chart_wuran_duibi_column.setOption(option);
}

var chart_air_quality_pie = echarts.init(document.getElementById('air_quality_pie'));
function air_quality_pie() {
    option = {
        title : {
            text: '5月份空气质量等级占比分布',
            subtext: '数据来自：罗克佳华',
            x:'center'
        },
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        legend: {
            x : 'center',
            y : 'bottom',
            data:['严重污染','重度污染','中度污染','轻度污染','良']
        },
        series: [
            {
                name:'污染天数',
                type:'pie',
                radius: ['50%', '70%'],
                avoidLabelOverlap: false,
                label: {
                    normal: {
                        show: false,
                        position: 'center'
                    },
                    emphasis: {
                        show: true,
                        textStyle: {
                            fontSize: '30',
                            fontWeight: 'bold'
                        }
                    }
                },
                labelLine: {
                    normal: {
                        show: false
                    }
                },
                data:[
                    {value:1, name:'严重污染'},
                    {value:1, name:'重度污染'},
                    {value:2, name:'中度污染'},
                    {value:13, name:'轻度污染'},
                    {value:14, name:'良'}
                ]
            }
        ]
    };
    chart_air_quality_pie.setOption(option);
}

// function resize() {
//     chart_scene_map.resize();
// }
$(window).resize(function () {
    chart_scene_map.resize();
    chart_real_time_aqi.resize();
    chart_source_star_map.resize();
    chart_gongxian_pie.resize();
    chart_wuran_duibi_column.resize();
    chart_air_quality_pie.resize();
})
var SceneMain=function()
{
    "use strict";
    return{
        init:function(){
            scene_liuliang();
            real_time_aqi();
            source_star_map();
            gongxian_pie();
            wuran_duibi_column();
            air_quality_pie();
            // scene_map();
            // scene_bar();
            // scene_pie()
        }
    }
}()
